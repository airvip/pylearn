#!/usr/bin/env python3
# -*- coding:utf-8 -*-
# Created by airvip on 2017/8/12 23:22.


def func1():
    print("in the func1 of test1")